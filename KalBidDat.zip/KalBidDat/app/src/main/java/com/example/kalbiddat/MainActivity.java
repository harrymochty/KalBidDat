package com.example.kalbiddat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText pnjng, lbr;
    Button btPersegi, btSegitiga, btLingkaran;
    TextView tvLuas, tvKeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pnjng=(EditText) findViewById(R.id.ipPanjang);
        lbr=(EditText) findViewById(R.id.ipLebar);
        tvLuas=(TextView) findViewById(R.id.hasilLuas);
        tvKeliling=(TextView) findViewById(R.id.hasilKeliling);
        btLingkaran=(Button) findViewById(R.id.btnLingkaran);
        btPersegi=(Button) findViewById(R.id.btnPersegi);
        btSegitiga=(Button) findViewById(R.id.btnSegitiga);

        btPersegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double panjang, lebar, luas, keliling;
                panjang=Double.valueOf(pnjng.getText().toString().trim());
                lebar=Double.valueOf(lbr.getText().toString().trim());
                luas=panjang*lebar;
                keliling=2*(panjang+lebar);
                String luas1=String.valueOf(luas);
                String keliling1=String.valueOf(keliling);
                tvLuas.setText(luas1);
                tvKeliling.setText(keliling1);
            }
        });
        btSegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double panjang, lebar, luas, keliling;
                panjang=Double.valueOf(pnjng.getText().toString().trim());
                lebar=Double.valueOf(lbr.getText().toString().trim());
                luas=0.5*panjang*lebar;
                keliling=panjang+lebar+lebar;
                String luas1=String.valueOf(luas);
                String keliling1=String.valueOf(keliling);
                tvLuas.setText(luas1);
                tvKeliling.setText(keliling1);
            }
        });
        btLingkaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double panjang, lebar, luas, keliling;
                panjang=Double.valueOf(pnjng.getText().toString().trim());
                lebar=Double.valueOf(lbr.getText().toString().trim());
                luas=3.14*0.5*(panjang)*0.5*(panjang);
                keliling=2*3.14*0.5*(panjang);
                String luas1=String.valueOf(luas);
                String keliling1=String.valueOf(keliling);
                tvLuas.setText(luas1);
                tvKeliling.setText(keliling1);
            }
        });
    }
}